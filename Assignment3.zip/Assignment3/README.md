CMPS320
Assignment 3

Overview
This program is a web-based application using PHP that interacts with a MySQL database. This web application provides the ability to create, read, update, and delete (CRUD) records and also generate a report based on the data stored in your database. The frontend is created with HTML/CSS and the backend logic is created using PHP. The database structure is stored in MySQL.

This web application is an employee management system which allows users to add, update, and delete employee records. The home page displays information stored in the database about all employees including their name, position, hire date, years worked, and annual salary. From the home page, the user can click "add employee", where they will submit all the required information in a form and the database and homepage will update accordingly. Similarly, the user can click update employee where again, they can update that specific employee's data by inputting/changing their information in a form. Lastly, the user can click the remove button next to the info of a specific employee to completely remove them from the system. 
 
Features:
- Add and update employee records by submitting new/changing information in a form
- Displays all employee's and their information - name, position, hire date, years worked, annual salary - in a table on the main page 
- User can completely remove an employee from the system (database) by clicking their corresponding remove button

Hosting Method: MAMP
How to run: Download the zip file containing the website code and assets and drag them into the MAMP htdocs folder. Then, open the MAMP application and press start in the upper right corner to run the website.