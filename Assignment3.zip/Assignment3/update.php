<?php
$db_name = "mysql:host=localhost;dbname=employee_system";
$db_user_name = "root";
$db_password = "root";

// Create connection
$conn = new PDO($db_name, $db_user_name, $db_password);
$conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

// Fetch employee details
$employee_id = $_POST['id'];
$get_employee = $conn->prepare("SELECT * FROM employees WHERE id = ?");
$get_employee->execute([$employee_id]);
$employee = $get_employee->fetch(PDO::FETCH_ASSOC);

// Update employee details with form inputs
if(isset($_POST['update_employee'])) {
    $name = $_POST['name'];
    $position = $_POST['position'];
    $hire_date = $_POST['hire_date'];
    $annual_salary = $_POST['annual_salary'];
    
    $update_employee = $conn->prepare("UPDATE employees SET name = ?, position = ?, hire_date = ?, salary = ? WHERE id = ?");
    $update_employee->execute([$name, $position, $hire_date, $annual_salary, $employee_id]);

    header("Location: index.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Employee Management System</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <h1>Update Employee</h1>
    <div class="button-container">
        <button type="button" name="back" onclick="window.location.href='index.php'">Back to Employee List</button>
    </div>
    <!-- Display current employee details in a form, allow user to update them -->
    <form action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>" method="post" name="update_employee">
        <fieldset>
            <div class="center">
        <input type="hidden" name="id" value="<?php echo htmlspecialchars($employee['id']); ?>">
        <label for="name">Name:</label>
        <input type="text" id="name" name="name" value="<?php echo htmlspecialchars($employee['name']); ?>"><br>

        <label for="position">Position:</label>
        <input type="text" id="position" name="position" value="<?php echo htmlspecialchars($employee['position']); ?>"><br>

        <label for="hire_date">Hire Date:</label>
        <input type="date" id="hire_date" name="hire_date" value="<?php echo htmlspecialchars($employee['hire_date']); ?>"><br>

        <label for="annual_salary">Annual Salary:</label>
        <input type="number" id="annual_salary" name="annual_salary" value="<?php echo htmlspecialchars($employee['salary']); ?>"><br>

        <button type="submit" name="update_employee">Update Employee</button>
</div>
</fieldset>
    </form>

