<?php
$db_name = "mysql:host=localhost;dbname=employee_system";
$db_user_name = "root";
$db_password = "root";

// Create connection
$conn = new PDO($db_name, $db_user_name, $db_password);
$conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

// Fetch all employees
$get_employees = $conn->prepare("SELECT * FROM employees");
$get_employees->execute();
$employees = $get_employees->fetchAll(PDO::FETCH_ASSOC);


// employee removal
if (isset($_POST['remove'])) {
    $employee_id = $_POST['id'];
    $remove_item = $conn->prepare("DELETE FROM employees WHERE id = ?");
    $remove_item->execute([$employee_id]);
    //Reload to prevent resubmission on refresh
    header("Location: index.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Employee Management System</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <h1>Employee Management System</h1>
    <!-- Add/update employee button -->
    <div class="button-container">
        <form action="add.php" method="post">
            <button type="submit" name="add">Add Employee</button>
        </form>
    </div>

    <!-- display all current employees in a table using a for loop -->
    <p>Here is a list of all the current employees in the system:</p>
    <table>
        <tr>
            <th>Name</th>
            <th>Position</th>
            <th>Hire Date</th>
            <th>Years Worked</th>
            <th>Annual Salary</th>
            <th>Remove</th>
            <th>Update</th>
        </tr>
        <?php if ($employees): ?>
            <?php foreach ($employees as $employee): ?>
                <!-- Calculate years worked -->
                <?php
                $hireDate = new DateTime($employee['hire_date']);
                $currentDate = new DateTime();
                $yearsWorked = $currentDate->diff($hireDate)->y;
                ?>
                <!-- Populate table with employee data -->
                <tr>
                    <td><?= htmlspecialchars($employee['name']) ?></td>
                    <td><?= htmlspecialchars($employee['position']) ?></td>
                    <td><?= htmlspecialchars($employee['hire_date']) ?></td>
                    <td><?= htmlspecialchars($yearsWorked) ?> year<?= $yearsWorked != 1 ? 's' : '' ?></td>
                    <td><?= number_format($employee['salary'], 2) ?></td>
                    <td>
                        <form method="post">
                            <input type="hidden" name="id" value="<?= htmlspecialchars($employee['id']) ?>">
                            <button type="submit" name="remove" onclick="return confirm('Are you sure you want to remove this employee?');">Remove</button>
                        </form>
                    </td>
                    <td>
                        <form method="post" action="update.php">
                            <input type="hidden" name="id" value="<?= htmlspecialchars($employee['id']) ?>">
                            <button type="submit" name="update">Update</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; ?>
        <?php else: ?>
            <tr>
                <td colspan="6" style="text-align: center;">No employees found.</td>
            </tr>
        <?php endif; ?>
    </table>
</body>
</html>
