CMPS320
Assignment 1 - 

Overview: This website is basic personal portfolio for myself. I chose to make a personal portfolio because in the future, once I start looking for jobs and completing more projects, it is definitely something I would like to create to show off my skills
Features: Basic HTML page, header, footer, navigations (with dummy links), image, styled with an external style sheet (CSS)
Hosting Method: MAMP
How to run: Download the zip file containing the website code and assets and drag them into the MAMP htdocs folder. Then, open the MAMP application and press start in the upper right corner to run the website.