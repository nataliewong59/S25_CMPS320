<!DOCTYPE html>
<html>
<body>
<h1>Here are your results:</h1>

<?php 
//calculate inches and bmi number
$inches = ($_POST["heightFeet"]*12) + $_POST["heightInches"];
$bmi = round(703*($_POST["weight"]/($inches*$inches)),2);

//conditional statement to determine classification based on bmi
$BMImeaning = "";
if ($bmi < 16){
    $BMImeaning = "Severe Thinness";
}
else if ($bmi >= 16 && $bmi < 17){
    $BMImeaning = "Moderate Thinness";
}
else if ($bmi >= 17 && $bmi < 18.5){
    $BMImeaning = "Mild Thinness";
}
else if ($bmi >= 18.5 && $bmi < 25){
    $BMImeaning = "Normal";
}
else if ($bmi >= 25 && $bmi < 30){
    $BMImeaning = "Overweight";
}
else if ($bmi >= 30 && $bmi < 35){
    $BMImeaning = "Obese Class I";
}
else if ($bmi >= 35 && $bmi < 40){
    $BMImeaning = "Obese Class II";
}
else{
    $BMImeaning = "Obese Class III";
}

echo "<p>Hi {$_POST['name']}, You are a {$_POST['gender']}. You are {$_POST['age']} years old. 
You are currently {$_POST['heightFeet']}'{$_POST['heightInches']} tall and you currently weigh {$_POST['weight']} pounds. 
Your BMI is {$bmi}, which is {$BMImeaning}. <br>Thank you for using the BMI Calculator!</p>";

?>

</body>
</html>