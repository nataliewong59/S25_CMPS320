CMPS320
Assignment 2 - Problem 1

Overview: 
This program calculates the user's BMI based on the information they inputted. The user inputs their name, age, gender, height by feet, height by inches, and weight in pounds. The program calculates the user's BMI based on their height and weight, then outputs it to the console.

Features:
user completes form and fills out their information (name, age, gender, height by feet, height by inches, weight in pounds)
calculates height in inches by multiplying feet by 12 and adding inches
calculates BMI using the formula BMI = 703*(weight/inches^2)
uses conditional statements to determine BMI number meaning
Echoes the user's inputted information and the BMI value and meaning in paragraph elements

Hosting Method: MAMP
How to run: Download the zip file containing the website code and assets and drag them into the MAMP htdocs folder. Then, open the MAMP application and press start in the upper right corner to run the website.