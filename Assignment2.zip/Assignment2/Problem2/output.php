<!DOCTYPE html>
<html>
<body>
<h1>Here are your results:</h1>

<?php 
//determining birthday meaning
        //month
        $monthString="";
        $monthMeaning="";
        switch($_POST["birthMonth"]){
            case "jan":
                $monthString = "January";
                $monthMeaning = "Janus";
                break;
            case "feb":
                $monthString = "February";
                $monthMeaning = "Februalia";
                break;
            case "mar":
                $monthString = "March";
                $monthMeaning = "Mars";
                break;
            case "apr":
                $monthString = "April";
                $monthMeaning = "Aperire";
                break;
            case "may":
                $monthString = "May";
                $monthMeaning = "Maia";
                break;
            case "jun":
                $monthString = "June";
                $monthMeaning = "Youth";
                break;
            case "july":
                $monthString = "July";
                $monthMeaning = "Julius Caeser";
                break;
            case "aug":
                $monthString = "August";
                $monthMeaning = "Augustus Caeser";
                break;
            case "sep":
                $monthString = "September";
                $monthMeaning = "Seven";
                break;
            case "oct":
                $monthString = "October";
                $monthMeaning = "Eight";
                break;
            case "nov":
                $monthString = "November";
                $monthMeaning = "Nine";
                break;
            case "dec":
                $monthString = "December";
                $monthMeaning = "Ten";
                break;
        }
        
        //day
        $daySuffix="";
        $dayMeaning="";
        switch($_POST["birthDay"]){
            case 1:
                $dayMeaning = "You are a self-starter";
                $daySuffix = "st";
                break;
            case 2:
                $dayMeaning = "you have a great talent for finding solutions";
                $daySuffix = "nd";
                break;
            case 3:
                $dayMeaning = "Expression comes naturally to you";
                $daySuffix = "rd";
                break;
            case 4:
                $dayMeaning = "You bring stability and rationality to any situation";
                $daySuffix = "th";
                break;
            case 5:
                $dayMeaning = "Flexibility is your forte";
                $daySuffix = "th";
                break;
            case 6:
                $dayMeaning = "Your heart is your gift";
                $daySuffix = "th";
                break;
            case 7:
                $dayMeaning = "You possess a very refined mind";
                $daySuffix = "th";
                break;
            case 8:
                $dayMeaning = "Yours is a story of success";
                $daySuffix = "th";
                break;
            case 9:
                $dayMeaning = "It's your compassion that makes you shine";
                $daySuffix = "th";
                break;
            case 10:
                $dayMeaning = "Great leadership skills";
                $daySuffix = "th";
                break;
            case 11:
                $dayMeaning = "You have a keen awareness of what's happening around you";
                $daySuffix = "th";
                break;
            case 12:
                $dayMeaning = "Creativity is a driving force in your life";
                $daySuffix = "th";
                break;
            case 13:
                $dayMeaning = "You are a conscientious worker";
                $daySuffix = "th";
                break;
            case 14:
                $dayMeaning = "You are open-minded and always up to try something new";
                $daySuffix = "th";
                break;
            case 15:
                $dayMeaning = "Your love for others is powerful ";
                $daySuffix = "th";
                break;
            case 16:
                $dayMeaning = "You have an inquisitive mind that allows you to uncover important truths";
                $daySuffix = "th";
                break;
            case 17:
                $dayMeaning = "The quality of work you can produce when you're going it alone is almost unbelievable";
                $daySuffix = "th";
                break;
            case 18:
                $dayMeaning = "You are both open-minded and open-hearted";
                $daySuffix = "th";
                break;
            case 19:
                $dayMeaning = "Independence and self-sufficiency are necessities to you";
                $daySuffix = "th";
                break;
            case 20:
                $dayMeaning = "You relate to others on an almost cosmic level";
                $daySuffix = "th";
                break;
            case 21:
                $dayMeaning = "You thrive in active social settings.";
                $daySuffix = "st";
                break;
            case 22:
                $dayMeaning = "You the power to create great things";
                $daySuffix = "nd";
                break;
            case 23:
                $dayMeaning = "You have a real zest for life";
                $daySuffix = "rd";
                break;
            case 24:
                $dayMeaning = "You have a heart of gold";
                $daySuffix = "th";
                break;
            case 25:
                $dayMeaning = "You have a great ability to take in and process information";
                $daySuffix = "th";
                break;
            case 26:
                $dayMeaning = "You have a desire to succeed";
                $daySuffix = "th";
                break;
            case 27:
                $dayMeaning = "Your mind is wide open and you are tolerant";
                $daySuffix = "th";
                break;
            case 28:
                $dayMeaning = "You recognize the value of working with others";
                $daySuffix = "th";
                break;
            case 29:
                $dayMeaning = "You have an amazing ability to bring things together";
                $daySuffix = "th";
                break;
            case 30:
                $dayMeaning = "You are an original, innovative thinker";
                $daySuffix = "th";
                break;
            case 31:
                $dayMeaning = "Your approach to life is an effective mix of both practicality and imagination";
                $daySuffix = "st";
                break;
        }
        
        //year
        $yearMeaning = "";
        switch($_POST["birthYear"]){
            case 2000:
                $yearMeaning = "You are moody and overconfident";
                break;
            case 2001:
                $yearMeaning = "You have a lot of energy and are very passionate about things";
                break;
            case 2002:
                $yearMeaning = "You dont like being restrained by convention";
                break;
            case 2003:
                $yearMeaning = "You have a tendency to worry";
                break;
            case 2004:
                $yearMeaning = "You are strong-willed, intelligent, and creative";
                break;
            case 2005:
                $yearMeaning = "You are honest, intelligent, and ambitious";
                break;
            case 2006:
                $yearMeaning = "You are straightforward in though and speech";
                break;
            case 2007:
                $yearMeaning = "People find you honest";
                break;
            case 2008:
                $yearMeaning = "You are easygoing and adaptable";
                break;
            case 2009:
                $yearMeaning = "You are silent and hardworking";
                break;
            case 2010:
                $yearMeaning = "You have a tendency to resist authority and want to do your own thing";
                break;
            case 2011:
                $yearMeaning = "You are sensitive and can take things to personally";
                break;
            case 2012:
                $yearMeaning = "You are impatient and want everything quickly";
                break;
            case 2013:
                $yearMeaning = "You have a lot of energy and have difficulty controlling it";
                break;
            case 2014:
                $yearMeaning = "You desire a high-profile career";
                break;
            case 2015:
                $yearMeaning = "Your strong faith has helped you through your life";
                break;
            case 2016:
                $yearMeaning = "You have spent your life caring for others";
                break;
            case 2017:
                $yearMeaning = "You show who you really are";
                break;
            case 2018:
                $yearMeaning = "You are moody and overconfident";
                break;
            case 2019:
                $yearMeaning = "You are very understanding";
                break;
            case 2020:
                $yearMeaning = "You are easygoing and talkative";
                break;
            case 2021:
                $yearMeaning = "You are sefless and compassioante";
                break;
            case 2022:
                $yearMeaning = "You are open-minded and empathetic";
                break;
            case 2023:
                $yearMeaning = "You are intelligent and determined";
                break;
        }

//output results
echo "<p>The month of $monthString means $monthMeaning</p>";
echo "<p>The {$_POST["birthDay"]}$daySuffix of $monthString means $dayMeaning</p>";
echo "<p>The year of {$_POST["birthYear"]} means that $yearMeaning</p><br>";

//ask if they want to go again, add button to redirect back to form
echo "Would you like to try another date?";
echo '<form method="post" action="index.html">
    <input type="submit" value="Play Again">
</form>';
?>

</body>
</html>