CMPS320
Assignment 2 - Problem 2

Overview
This program will ask the user to input their birthday month, day, and year, and determine (using switch statements) and print the appropriate meaning for all three elements. The user will be asked at the end if they want to enter another birthday using a loop.

Features:
prompt user to fill out their birthday day, month, year in a form
determine appropriate meaning according to each input using switch statements
echoes results in paragraph elements
Button that allows user to return to the form page if they want to input another birthday

Hosting Method: MAMP
How to run: Download the zip file containing the website code and assets and drag them into the MAMP htdocs folder. Then, open the MAMP application and press start in the upper right corner to run the website.