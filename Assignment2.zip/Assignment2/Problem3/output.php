<!DOCTYPE html>
<html>
<body>
<h1>Here are your results:</h1>

<?php 
//switch statement to determine operand, calculate accordingly, and output the answer
$answer = 0;
        switch($_POST["operand"]){
            case "+":
                $answer = $_POST["firstNumber"] + $_POST["secondNumber"];
                echo "<p>You inputted: {$_POST["firstNumber"]} + {$_POST["secondNumber"]}, the answer is: $answer</p>";
                break;
            case "-":
                $answer = $_POST["firstNumber"] - $_POST["secondNumber"];
                echo "<p>You inputted: {$_POST["firstNumber"]} - {$_POST["secondNumber"]}, the answer is: $answer</p>";
                break;
            case "*":
                $answer = round($_POST["firstNumber"] * $_POST["secondNumber"],3);
                echo "<p>You inputted: {$_POST["firstNumber"]} * {$_POST["secondNumber"]}, the answer is: $answer</p>";
                break;
            case "/":
                $answer = round($_POST["firstNumber"] / $_POST["secondNumber"],3);
                echo "<p>You inputted: {$_POST["firstNumber"]} / {$_POST["secondNumber"]}, the answer is: $answer</p>";
                break;
            case "%":
                $answer = $_POST["firstNumber"] % $_POST["secondNumber"];
                echo "<p>You inputted: {$_POST["firstNumber"]} % {$_POST["secondNumber"]}, the answer is: $answer</p>";
                break;
            case "^":
                $answer = pow($_POST["firstNumber"],$_POST["secondNumber"]);
                echo "<p>You inputted: {$_POST["firstNumber"]}^{$_POST["secondNumber"]}, the answer is: $answer</p>";
                break;
            case "sin":
                $answer = round(sin($_POST["firstNumber"]),3);
                echo "<p>You inputted: sin({$_POST["firstNumber"]}), the answer is: $answer</p>";
                break;
            case "asin":
                $answer = round(asin($_POST["firstNumber"]),3);
                echo "<p>You inputted: asin({$_POST["firstNumber"]}), the answer is: $answer</p>";
                break;
            case "cos":
                $answer = round(cos($_POST["firstNumber"]),3);
                echo "<p>You inputted: cos({$_POST["firstNumber"]}), the answer is: $answer</p>";
                break;
            case "acos":
                $answer = round(cos($_POST["firstNumber"]),3);
                echo "<p>You inputted: acos({$_POST["firstNumber"]}), the answer is: $answer</p>";
                break;
            case "tan":
                $answer = round(tan($_POST["firstNumber"]),3);
                echo "<p>You inputted: tan({$_POST["firstNumber"]}), the answer is: $answer</p>";
                break;
            case "atan":
                $answer = round(atan($_POST["firstNumber"]),3);
                echo "<p>You inputted: tan({$_POST["firstNumber"]}), the answer is: $answer</p>";
                break;
            case "atan2":
                $answer = round(atan2($_POST["firstNumber"]),3);
                echo "<p>You inputted: atan2({$_POST["firstNumber"]}), the answer is: $answer</p>";
                break;
            case "sqrt":
                $answer = round(sqrt($_POST["firstNumber"]),3);
                echo "<p>You inputted: sqrt({$_POST["firstNumber"]}), the answer is: $answer</p>";
                break;
            case "ceil":
                $answer = ceil($_POST["firstNumber"]);
                echo "<p>You inputted: ceil({$_POST["firstNumber"]}), the answer is: $answer</p>";
                break;
            case "abs":
                $answer = abs($_POST["firstNumber"]);
                echo "<p>You inputted: abs({$_POST["firstNumber"]}), the answer is: $answer</p>";
                break;
            case "floor":
                $answer = floor($_POST["firstNumber"]);
                echo "<p>You inputted: floor({$_POST["firstNumber"]}), the answer is: $answer</p>";
                break;
            case "max":
                $answer = max($_POST["firstNumber"],$_POST["secondNumber"]);
                echo "<p>You inputted: max({$_POST["firstNumber"]},{$_POST["secondNumber"]}), the answer is: $answer</p>";
                break;
            case "min":
                $answer = min($_POST["firstNumber"],$_POST["secondNumber"]);
                echo "<p>You inputted: min({$_POST["firstNumber"]},{$_POST["secondNumber"]}), the answer is: $answer</p>";
                break;
            case "log":
                $answer = round(log($_POST["firstNumber"]),3);
                echo "<p>You inputted: log({$_POST["firstNumber"]}), the answer is: $answer</p>";
                break;
            case "log10":
                $answer = round(log10($_POST["firstNumber"]),3);
                echo "<p>You inputted: log10({$_POST["firstNumber"]}), the answer is: $answer</p>";
                break;
            case "log3":
                $answer = round(log3($_POST["firstNumber"]),3);
                echo "<p>You inputted: log3({$_POST["firstNumber"]}), the answer is: $answer</p>";
                break;
            case "round":
                $answer = round($_POST["firstNumber"]);
                echo "<p>You inputted: round({$_POST["firstNumber"]}), the answer is: $answer</p>";
                break;
        }

?>

</body>
</html>