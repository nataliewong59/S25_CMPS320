CMPS320
Assignment 2 - Problem 3

Overview
The program will ask the user to enter the type (operand) of math problem they would like to solve. Using a conditional statement to determine what they pick, the program will then ask for additional inputs such as numbers to calculate the answer. The answer will be calculated and printed.

Features:
prompt user to input type of math problem (e.g. +, sin, log, max, etc...) and first/second(if applicable) number in a form
determine operand based on their input using a switch statement
calculate the answer and echo it in a paragraph elements 
Rounds all answers to 3 decimal places

Hosting Method: MAMP
How to run: Download the zip file containing the website code and assets and drag them into the MAMP htdocs folder. Then, open the MAMP application and press start in the upper right corner to run the website.